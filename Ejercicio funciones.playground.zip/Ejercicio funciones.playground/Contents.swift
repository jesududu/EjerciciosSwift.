import Foundation

/// Concatena múltiples cadenas usando un separador opcional y permite invertir el orden si se requiere.
///
/// - parameters:
///   - strings: un array de cadenas a combinar (`String`).
///   - separator: un separador opcional que se colocará entre las cadenas. el valor por defecto es `" "`.
///   - shouldReverse: un booleano que indica si el orden de las cadenas pasadas como parámetro deben invertirse antes de ser concatenadas. El valor por defecto es `false`.
///
/// - returns: una sola cadena que combina las cadenas separadas por el separador indicado.
///
/// - note: las cadenas vacías no se incluirán en el resultado final.
///
/// Ejemplo de uso:
/// ```swift
/// let resultado = concatenateStrings(["Swift", "es", "genial"], withSeparator: "-", andReverse: true)
/// print(resultado) // salida: genial-es-Swift
/// ```
func concatenateStrings(
    _ strings: [String],
    withSeparator separator: String = " ",
    andReverse shouldReverse: Bool = false
) -> String {
    // Filtrar cadenas vacías
    let filteredStrings = strings.filter { !$0.isEmpty }
    
    // Invertir el orden si es necesario
    let finalStrings = shouldReverse ? filteredStrings.reversed() : filteredStrings
    
    // Unir las cadenas con el separador
    return finalStrings.joined(separator: separator)
}

let resultado = concatenateStrings(["Swift", "es", "genial"], withSeparator: "-", andReverse: true)
print(resultado) // salida: genial-es-Swift

/// Genera un saludo basado en la hora del día y el nombre del usuario.
///
/// - parameters:
///   - name: el nombre del usuario al cual se desea saludar (`String`).
///   - hour: la hora actual, utilizando el formato de 24 horas (`Int`).
///
/// - returns: un saludo personalizado dependiendo de la hora del día. Si la hora no está entre 0 y 23, se retorna un saludo genérico.
///
/// - note: esta función considera las siguientes franjas horarias:
///   * 0 a 11: "Buenos días"
///   * 12 a 17: "Buenas tardes"
///   * 18 a 23: "Buenas noches"
///
/// Ejemplo de uso:
/// ```swift
/// let saludo = generateGreeting(forName: "Ana", atHour: 15)
/// print(saludo) // salida: Buenas tardes, Ana
/// ```



/// Representa las franjas horarias del día.
enum TimeOfDay {
    case morning, afternoon, evening, unknown
    static func from(hour: Int) -> TimeOfDay {
        switch hour {
        case 0...11:
            return .morning
        case 12...17:
            return .afternoon
        case 18...23:
            return .evening
        default:
            return .unknown
        }
    }
}

func generateGreeting(forName name: String, atHour hour: Int) -> String {
    let timeOfDay = TimeOfDay.from(hour: hour)

    switch timeOfDay {
    case .morning:
        return "Buenos días, \(name)"
    case .afternoon:
        return "Buenas tardes, \(name)"
    case .evening:
        return "Buenas noches, \(name)"
    case .unknown:
        return "Hola, \(name)"
    }
}

let saludo = generateGreeting(forName: "Ana", atHour: 15)
print(saludo) // salida: Buenas tardes, Ana






/// Convierte un valor monetario de una moneda a otra utilizando una tasa de cambio específica.
///
/// - parameters:
///   - amount: el valor monetario que se desea convertir (`Double`).
///   - sourceCurrency: el código de 3 letras que representa la moneda de origen (`String`).
///   - targetCurrency: el código de 3 letras que representa la moneda destino (`String`).
///   - exchangeRate: la tasa de cambio que se utilizará para realizar la conversión (`Double`).
///
/// - returns: una cadena con el valor convertido y las monedas involucradas. Si la tasa de cambio es inválida (menor o igual a 0), se devuelve un mensaje de error.
///
/// - note: el valor convertido se calcula multiplicando el monto por la tasa de cambio.
///
/// Ejemplo de uso:
/// ```swift
/// let conversion = convertCurrency(100, from: "USD", to: "EUR", withRate: 0.85)
/// print(conversion) // salida: 100.0 USD es equivalente a 85.0 EUR
/// ```
///
/// Ejemplo de error:
/// ```swift
/// let conversion = convertCurrency(100, from: "USD", to: "EUR", withRate: -0.1)
/// print(conversion) // salida: Error: la tasa de cambio debe ser mayor que 0.
/// ```
///
func convertCurrency(_ amount: Double, from sourceCurrency: String, to targetCurrency: String, withRate exchangeRate: Double) -> String {
    if exchangeRate <= 0 {
        return "Error: la tasa de cambio debe ser mayor que 0."
    }
    
    let convertedAmount = amount * exchangeRate
    let formattedAmount = String(format: "%.1f", convertedAmount)
    let formattedInitialAmount = String(format: "%.1f", amount)
    
    return "\(formattedInitialAmount) \(sourceCurrency) es equivalente a \(formattedAmount) \(targetCurrency)"
}

let conversion = convertCurrency(100.0, from: "USD", to: "EUR", withRate: 0.85)
print(conversion)

let conversionError = convertCurrency(100.0, from: "USD", to: "EUR", withRate: -0.1)
print(conversionError)

/// Calcula el precio total de una compra y aplica un descuento opcional.
///
/// - parameters:
///   - prices: un array de precios de productos (`Double`) para calcular el total.
///   - discount: un porcentaje de descuento opcional que se aplicará sobre el precio total. El valor por defecto es `0`.
///   - shouldLog: un booleano que indica si se debe imprimir el detalle del cálculo en la consola. El valor por defecto es `false`.
///
/// - returns: una tupla con:
///   * `total`: el precio total antes del descuento.
///   * `discountedTotal`: el precio final después de aplicar el descuento.
///
/// - note: si el descuento es mayor al 100%, el precio resultante será negativo.
/// - important: es recomendable pasar precios positivos, ya que los valores negativos no serán válidos.
///
/// Ejemplo de uso:
/// ```swift
/// let compra = calculateTotalPrice(for: [50.0, 60.0], withDiscount: 20, shouldLog: true)
/// print("Total: \(compra.total), Total con descuento: \(compra.discountedTotal)")
/// ```
///
/// Output esperado para el ejemplo anterior:
/// ```
/// Calculando compra: [50.0, 60.0]
/// Descuento aplicado: 20.0%
/// Precio total: 110.0
/// Precio con descuento: 88.0
/// Total: 110.0, Total con descuento: 88.0
/// ```
func calculateTotalPrice(for prices: [Double], withDiscount discount: Double = 0, shouldLog: Bool = false) -> (total: Double, discountedTotal: Double) {
    
    let total = prices.reduce(0, +)
    
    let discountFactor = 1 - (discount / 100)
    let discountedTotal = total * discountFactor
    
    if shouldLog {
        print("Calculando compra: \(prices)")
        print("Descuento aplicado: \(discount)%")
        print("Precio total: \(total)")
        print("Precio con descuento: \(discountedTotal)")
    }
    
    return (total, discountedTotal)
}

let compra = calculateTotalPrice(for: [50.0, 60.0], withDiscount: 20, shouldLog: true)
print("Total: \(compra.total), Total con descuento: \(compra.discountedTotal)")
