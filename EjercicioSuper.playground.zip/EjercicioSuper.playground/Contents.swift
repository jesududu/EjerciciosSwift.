import UIKit

let nombreSupermercado: String = "Super Awesome Market"
let direccionSupermercado: String = "Calle Ficticia, 123"
let aniosOperando: Int = 10
let nivelSatisfaccionPromedio: Float = 4.5
var isOpen: Bool = true
var inventario = ["manzanas", "plátanos", "leche", "huevos", "pan"]

// Agregar "caramelos" al final del array
inventario.append("caramelos")

// Imprimir el número total de productos
print("Número total de productos en el inventario: \(inventario.count)")

var clientesFrecuentes: Set<String> = ["alice", "bob", "charlie"]

// Agregar un nuevo cliente llamado "diana"
clientesFrecuentes.insert("diana")

// Eliminar al cliente "charlie"
clientesFrecuentes.remove("charlie")

// Verificar si "alice" es aún cliente frecuente
let esAliceFrecuente = clientesFrecuentes.contains("alice")


print("Clientes frecuentes: \(clientesFrecuentes)")
print("¿Alice sigue siendo cliente frecuente? \(esAliceFrecuente)")


let weeklyOffer = (producto: "manzanas", precioOriginal: 2.99, descuento: 20)

// Calcular el precio descontado
let precioDescontado = weeklyOffer.precioOriginal * (1 - Double(weeklyOffer.descuento) / 100)

print("Producto en oferta: \(weeklyOffer.producto)")
print("Precio original: \(weeklyOffer.precioOriginal)€")
print("Descuento aplicado: \(weeklyOffer.descuento)%")
print("Precio con descuento: \(precioDescontado)€")


var salesRecord: [String: Int] = [
    "manzanas": 50,
    "plátanos": 30,
    "leche": 20,
    "huevos": 10
]


salesRecord["manzanas", default: 0] += 5 // Sumar 5 manzanas vendidas
salesRecord["huevos"] = 0 // Los huevos están agotados

// Recorrer e imprimir el diccionario
for (producto, cantidad) in salesRecord {
    print("Producto: \(producto), Cantidad vendida: \(cantidad)")
}
