//
//  UserServiceTests.swift
//  UserServiceTests
//
//  Created by Jesus Bueno on 16/2/25.
//

import XCTest

class UserServiceTests: XCTestCase {

    var userService: UserService!

    override func setUp() {
        super.setUp()
        userService = UserService()
    }

    override func tearDown() {
        userService = nil
        super.tearDown()
    }

    // Prueba para verificar la adición de un nuevo usuario
    func testAddUser() {
        let result = userService.addUser(name: "TestUser", email: "test@example.com", password: "password")
        XCTAssertTrue(result, "Adding user should succeed")
        
        // Verifica que el usuario se ha añadido correctamente
        let addedUser = userService.listUsers().first(where: { $0.email == "test@example.com" })
        XCTAssertNotNil(addedUser, "User should be added to the list")
        XCTAssertEqual(addedUser?.name, "TestUser", "User name should match")
        XCTAssertEqual(addedUser?.role, "user", "User role should be 'user'")
    }

    // Prueba para verificar que no se pueden añadir usuarios duplicados por email
    func testAddDuplicateUser() {
        _ = userService.addUser(name: "FirstUser", email: "duplicate@example.com", password: "password")
        let result = userService.addUser(name: "SecondUser", email: "duplicate@example.com", password: "anotherpassword")
        XCTAssertFalse(result, "Should not be able to add user with existing email")
    }

    // Prueba para recuperar un usuario
    func testGetUser() {
        userService.addUser(name: "TestUser", email: "test@example.com", password: "password")
        let user = userService.getUser(email: "test@example.com", password: "password")
        XCTAssertNotNil(user, "User should be retrievable after being added")
        XCTAssertEqual(user?.name, "TestUser", "Retrieved user name should match")
    }

    // Prueba para eliminar un usuario
    func testDeleteUser() {
        userService.addUser(name: "UserToDelete", email: "delete@example.com", password: "password")
        let deletedCount = userService.deleteUser(name: "UserToDelete")
        XCTAssertEqual(deletedCount, 1, "One user should be deleted")
        let remainingUsers = userService.listUsers().filter { $0.name == "UserToDelete" }
        XCTAssertTrue(remainingUsers.isEmpty, "No users with name 'UserToDelete' should remain")
    }

    // Prueba para listar usuarios
    func testListUsers() {
        userService.addUser(name: "UserA", email: "userA@example.com", password: "passwordA")
        userService.addUser(name: "UserB", email: "userB@example.com", password: "passwordB")
        let users = userService.listUsers()
        XCTAssertEqual(users.count, userService.users.count, "Listed users should match stored users")
        XCTAssertTrue(users.contains { $0.name == "UserA" }, "UserA should be listed")
        XCTAssertTrue(users.contains { $0.name == "UserB" }, "UserB should be listed")
    }
}
