import XCTest

class GraphTests: XCTestCase {

    var graph: Graph!

    override func setUp() {
        super.setUp()
        graph = Graph()
    }

    override func tearDown() {
        graph = nil
        super.tearDown()
    }

    // Prueba para verificar la adición de un vértice
    func testAddVertex() {
        graph.addVertex("A")
        XCTAssertNotNil(graph.vertices["A"], "Vertex 'A' should be added to the graph")
        XCTAssertTrue(graph.vertices["A"]?.isEmpty ?? false, "Vertex 'A' should have no edges")
    }

    // Prueba para verificar la adición de una arista
    func testAddEdge() {
        graph.addEdge(from: "A", to: "B", weight: <#Double#>)
        XCTAssertEqual(graph.vertices["A"], ["B"], "Vertex 'A' should connect to 'B'")
        XCTAssertTrue(graph.vertices["B"]?.isEmpty ?? false, "Vertex 'B' should have no outgoing edges")
    }

    // Prueba para verificar la obtención de vecinos de un vértice
    func testGetNeighbors() {
        graph.addEdge(from: "A", to: "B", weight: <#Double#>)
        graph.addEdge(from: "A", to: "C", weight: <#Double#>)
        let neighbors = graph.getNeighbors(of: "A")
        XCTAssertNotNil(neighbors, "Neighbors of 'A' should exist")
        XCTAssertEqual(Set(neighbors!), Set(["B", "C"]), "Neighbors of 'A' should be 'B' and 'C'")
    }

    // Prueba para asegurar que no se añaden vértices duplicados
    func testAddDuplicateVertex() {
        graph.addVertex("A")
        graph.addVertex("A") // Intentamos añadir el mismo vértice dos veces
        XCTAssertEqual(graph.vertices.count, 1, "There should only be one vertex 'A'")
    }

    // Prueba para asegurar que no se añaden aristas duplicadas
    func testAddDuplicateEdge() {
        graph.addEdge(from: "A", to: "B", weight: <#Double#>)
        graph.addEdge(from: "A", to: "B", weight: <#Double#>) // Intentamos añadir la misma arista dos veces
        XCTAssertEqual(graph.vertices["A"], ["B"], "Vertex 'A' should only connect to 'B' once")
    }
}
