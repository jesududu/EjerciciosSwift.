struct App {
    func run() {
        // Inicializar rutas al inicio de la aplicación
        initializeRoutes()
        
        // Continuar con el resto de la lógica de la aplicación
        let loginController = LoginController()
        loginController.start()
    }
}
