import Foundation

// MARK: - Grafo

/// Representa un nodo en un grafo con una lista de vecinos y sus respectivos pesos.
public struct GraphNode: Hashable {
    let name: String
    var neighbors: [GraphNode: Double] = [:]
    
    /// Implementa el protocolo Hashable para permitir el uso de GraphNode como clave en diccionarios.
    public func hash(into hasher: inout Hasher) {
        hasher.combine(name)
    }
    
    /// Compara dos GraphNode por su nombre para cumplir con el protocolo Equatable.
    public static func == (lhs: GraphNode, rhs: GraphNode) -> Bool {
        return lhs.name == rhs.name
    }
    
    /// Añade un vecino al nodo actual con el peso especificado.
    /// - Parameters:
    ///   - neighbor: El nodo vecino a añadir.
    ///   - weight: El peso de la conexión entre los nodos.
    mutating func addNeighbor(_ neighbor: GraphNode, weight: Double) {
        neighbors[neighbor] = weight
    }
}

/// Estructura que representa un grafo dirigido con nodos y aristas ponderadas.
public struct Graph {
    /// Diccionario que mantiene los nodos del grafo por su nombre.
    public var vertices: [String: GraphNode] = [:]
    
    /// Añade un nuevo vértice al grafo.
    /// - Parameter name: Nombre del vértice a añadir.
   public mutating func addVertex(_ name: String) {
        if vertices[name] == nil {
            vertices[name] = GraphNode(name: name)
        }
    }
    
    /// Añade una arista entre dos vértices con un peso específico.
    /// - Parameters:
    ///   - source: Nombre del vértice de origen.
    ///   - destination: Nombre del vértice de destino.
    ///   - weight: Peso de la arista.
    public mutating func addEdge(from source: String, to destination: String, weight: Double) {
        if var sourceNode = vertices[source], let destNode = vertices[destination] {
            sourceNode.addNeighbor(destNode, weight: weight)
            vertices[source] = sourceNode  // Actualiza el nodo en el diccionario
        } else {
            print("Uno o ambos nodos no existen.")
        }
    }
    
    /// Recupera un nodo del grafo por su nombre.
    /// - Parameter name: El nombre del nodo a buscar.
    /// - Returns: Un GraphNode si existe, nil en caso contrario.
   public func getNode(_ name: String) -> GraphNode? {
        return vertices[name]
    }
    
    /// Devuelve todos los nodos del grafo como un array.
    /// - Returns: Array de todos los GraphNode en el grafo.
    func allNodes() -> [GraphNode] {
        return Array(vertices.values)
    }
}
