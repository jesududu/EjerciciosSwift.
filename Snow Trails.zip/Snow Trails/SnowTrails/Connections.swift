import Foundation

typealias Connections = [String: [String]]

let connections: Connections = [
    "Alpina Grande": ["Pico Nevado", "Valle Blanco", "Cumbre Azul", "Alpina Pequeña"],
    "Alpina Pequeña": ["Alpina Grande"],
    "Pico Nevado": ["Alpina Grande", "Lago Helado", "Cerro Plateado"],
    "Valle Blanco": ["Alpina Grande", "Refugio Alpino"],
    "Cumbre Azul": ["Alpina Grande", "Cerro Plateado"],
    "Lago Helado": ["Pico Nevado", "Bosque Nevado"],
    "Bosque Nevado": ["Lago Helado", "Cascada Blanca", "Cerro Plateado"],
    "Cerro Plateado": ["Pico Nevado", "Cumbre Azul", "Bosque Nevado", "Cascada Blanca"],
    "Cascada Blanca": ["Cerro Plateado", "Bosque Nevado"],
    "Refugio Alpino": ["Valle Blanco"],
    "Refugio Aislado": []
]
