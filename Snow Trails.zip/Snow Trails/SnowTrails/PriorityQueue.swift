import Foundation

/// Estructura que implementa una cola de prioridad basada en un heap binario mínimo.
/// Los elementos con menor prioridad son extraídos primero.
struct PriorityQueue<T> {
    /// Array que almacena los elementos de la cola junto con sus prioridades.
    private var heap = [(element: T, priority: Double)]()
    
    /// Inserta un nuevo elemento en la cola con una prioridad dada.
    /// - Parameters:
    ///   - element: El elemento a insertar en la cola.
    ///   - priority: La prioridad asociada al elemento (menor valor = mayor prioridad).
    mutating func enqueue(_ element: T, priority: Double) {
        // Añade el elemento al final del heap
        heap.append((element, priority))
        var index = heap.count - 1
        // Reorganiza hacia arriba (heapify up) para mantener la propiedad del heap
        while index > 0 && heap[index].priority < heap[parent(of: index)].priority {
            heap.swapAt(index, parent(of: index))
            index = parent(of: index)
        }
    }
    
    /// Extrae y retorna el elemento con la menor prioridad (dequeue).
    /// - Returns: El elemento con la menor prioridad si existe, `nil` si la cola está vacía.
    mutating func dequeue() -> T? {
        // Verifica si la cola está vacía
        guard !heap.isEmpty else { return nil }
        let root = heap[0] // Elemento con menor prioridad (raíz del heap)
        // Mueve el último elemento a la raíz y elimina el último
        heap[0] = heap.removeLast()
        // Reorganiza hacia abajo (heapify down) para mantener la propiedad del heap
        heapifyDown(from: 0)
        return root.element
    }
    
    /// Actualiza la prioridad de un elemento en un índice específico.
    /// - Parameters:
    ///   - index: Índice del elemento cuya prioridad se actualizará.
    ///   - priority: Nueva prioridad para el elemento.
    mutating func updatePriority(_ index: Int, priority: Double) {
        // Verifica si el índice es válido
        if index < heap.count {
            heap[index].priority = priority
            // Reorganiza hacia arriba y hacia abajo para mantener la propiedad del heap
            heapifyUp(from: index)
            heapifyDown(from: index)
        }
    }
    
    /// Calcula el índice del nodo padre para un índice dado.
    /// - Parameter index: Índice del nodo hijo.
    /// - Returns: Índice del nodo padre.
    private func parent(of index: Int) -> Int {
        return (index - 1) / 2
    }
    
    /// Calcula el índice del hijo izquierdo para un índice dado.
    /// - Parameter index: Índice del nodo padre.
    /// - Returns: Índice del hijo izquierdo.
    private func leftChild(of index: Int) -> Int {
        return 2 * index + 1
    }
    
    /// Calcula el índice del hijo derecho para un índice dado.
    /// - Parameter index: Índice del nodo padre.
    /// - Returns: Índice del hijo derecho.
    private func rightChild(of index: Int) -> Int {
        return 2 * index + 2
    }
    
    /// Reorganiza el heap hacia arriba para mantener la propiedad del heap después de actualizar una prioridad.
    /// - Parameter index: Índice desde donde empezar la reorganización.
    mutating func heapifyUp(from index: Int) {
        var currentIndex = index
        // Mientras no estemos en la raíz y el nodo actual tenga menor prioridad que su padre
        while currentIndex > 0 && heap[currentIndex].priority < heap[parent(of: currentIndex)].priority {
            heap.swapAt(currentIndex, parent(of: currentIndex))
            currentIndex = parent(of: currentIndex)
        }
    }
    
    /// Reorganiza el heap hacia abajo para mantener la propiedad del heap después de extraer un elemento.
    /// - Parameter index: Índice desde donde empezar la reorganización.
    mutating func heapifyDown(from index: Int) {
        var currentIndex = index
        while true {
            let left = leftChild(of: currentIndex)
            let right = rightChild(of: currentIndex)
            var smallest = currentIndex
            
            // Compara con el hijo izquierdo
            if left < heap.count && heap[left].priority < heap[smallest].priority {
                smallest = left
            }
            
            // Compara con el hijo derecho
            if right < heap.count && heap[right].priority < heap[smallest].priority {
                smallest = right
            }
            
            // Si el nodo actual es el menor, hemos terminado
            if smallest == currentIndex { break }
            
            // Intercambia con el menor hijo y continúa hacia abajo
            heap.swapAt(currentIndex, smallest)
            currentIndex = smallest
        }
    }
    
    /// Encuentra el índice de un elemento específico en la cola.
    /// - Parameter element: Elemento a buscar.
    /// - Returns: Índice del elemento si se encuentra, `nil` en caso contrario.
    /// - Note: Requiere que T conforme al protocolo Equatable.
    func index(of element: T) -> Int? where T: Equatable {
        return heap.firstIndex { $0.element == element }
    }
}
