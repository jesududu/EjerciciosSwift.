import Foundation

struct Route {
    let name: String
    let points: [Point]

    func calculateDistance() -> Double {
        // Si la ruta tiene un solo punto, la distancia es 0
        if points.count <= 1 {
            return 0.0
        }
        
        // Usamos zip para iterar sobre pares de puntos consecutivos
        let pointPairs = zip(points, points.dropFirst())
        return pointPairs.reduce(0) { (total, pair) in
            total + Route.distanceBetween(pair.0, pair.1)
        }
    }

    static func distanceBetween(_ p1: Point, _ p2: Point) -> Double {
        // Fórmula de Haversine para calcular la distancia entre dos puntos
        let R = 6371e3 // meters
        let φ1 = p1.latitude * .pi / 180
        let φ2 = p2.latitude * .pi / 180
        let Δφ = (p2.latitude - p1.latitude) * .pi / 180
        let Δλ = (p2.longitude - p1.longitude) * .pi / 180
        
        let a = sin(Δφ/2) * sin(Δφ/2) + cos(φ1) * cos(φ2) * sin(Δλ/2) * sin(Δλ/2)
        let c = 2 * atan2(sqrt(a), sqrt(1-a))
        
        return R * c / 1000 // Convertir de metros a kilómetros
    }

    static var routes: [Route] = []

    static func initializeRoutes(with points: [Point]) {
        routes = [
            Route(name: "Ruta del Pico Nevado y Lago Helado", points: [
                points[0], // Alpina Grande
                points[2], // Pico Nevado
                points[5]  // Lago Helado
            ]),
            Route(name: "Ruta del Valle Blanco y Refugio Alpino", points: [
                points[0], // Alpina Grande
                points[3], // Valle Blanco
                points[9]  // Refugio Alpino
            ]),
            Route(name: "Ruta de la Cumbre Azul y Cerro Plateado", points: [
                points[0], // Alpina Grande
                points[4], // Cumbre Azul
                points[7]  // Cerro Plateado
            ]),
            Route(name: "Ruta del Bosque Nevado y Cascada Blanca", points: [
                points[5], // Lago Helado
                points[6], // Bosque Nevado
                points[8]  // Cascada Blanca
            ]),
            Route(name: "Ruta completa de Alpina Grande a Cascada Blanca", points: [
                points[0], // Alpina Grande
                points[2], // Pico Nevado
                points[5], // Lago Helado
                points[6], // Bosque Nevado
                points[8]  // Cascada Blanca
            ]),
            Route(name: "Ruta del Refugio Aislado", points: [
                points[10] // Refugio Aislado
            ]),
            Route(name: "Ruta Alpina", points: [
                points[0], // Alpina Grande
                points[1]  // Alpina Pequeña
            ])
        ]
    }
}
