import Foundation


import Foundation

struct Point {
    let name: String
    let latitude: Double
    let longitude: Double
    let elevation: Double
}
