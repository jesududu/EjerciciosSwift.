import Foundation

public struct User {
    let name: String
    let email: String
    let password: String
    let role: String
    
    static let initialUsers = [
        User(name: "Adminuserkeepcoding1", email: "adminuser@keepcoding.es", password: "Adminuser1", role: "admin"),
        User(name: "Regularuserkeepcoding1", email: "regularuser@keepcoding.es", password: "Regularuser1", role: "user")
    ]
    
    func getRole() throws -> String {
        guard !role.isEmpty else {
            throw NSError(domain: "User Error", code: 1, userInfo: [NSLocalizedDescriptionKey: "No se pudo obtener el rol del usuario."])
        }
        return role
    }
}
