import Foundation

let app = App()
app.run()
