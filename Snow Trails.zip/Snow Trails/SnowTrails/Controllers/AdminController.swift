import Foundation

class AdminController {
    let user: User
    private var userService = UserService()
    
    init(user: User) {
        self.user = user
    }
    
    func start() {
        while true {
            print("Menú admin - Selecciona una opción:")
            print("1. Ver todos los usuarios")
            print("2. Añadir usuario")
            print("3. Eliminar usuario")
            print("4. Añadir punto a una ruta")
            print("5. Logout")
            
            if let choice = readLine(), let option = Int(choice) {
                switch option {
                case 1:
                    listUsers()
                case 2:
                    addUser()
                case 3:
                    removeUser()
                case 4:
                    addPointToRoute()
                case 5:
                    print("Cerrando sesión.")
                    return
                default:
                    print("Opción no válida.")
                }
            }
        }
    }
    
    private func listUsers() {
        userService.listUsers().forEach { user in
            print("\(user.role == "admin" ? "Admin" : "Regular user"): \(user.name) --- Email: \(user.email)")
        }
    }
    
    private func addUser() {
        print("Introduce el nombre del usuario que quieres añadir:")
        guard let name = readLine() else { return }
        print("Introduce el email del usuario que quieres añadir:")
        guard let email = readLine() else { return }
        print("Introduce la contraseña del usuario que quieres añadir:")
        guard let password = readLine() else { return }
        
        if userService.addUser(name: name, email: email, password: password) {
            print("Usuario \(name) con email \(email) añadido satisfactoriamente")
        } else {
            print("No se pudo añadir el usuario. Revisa las restricciones.")
        }
    }
    
    private func removeUser() {
        print("Introduce el nombre del usuario a eliminar:")
        guard let name = readLine() else { return }
        
        let usersRemoved = userService.deleteUser(name: name)
        
        if usersRemoved > 0 {
            print("\(usersRemoved) usuario(s) con el nombre \(name) eliminados.")
        } else {
            print("Error: No se encontró ningún usuario con el nombre \(name).")
        }
    }
    
    private func addPointToRoute() {
        print("Introduce el nombre de la ruta a la que quieres añadir un punto:")
        guard let routeName = readLine(), let routeIndex = Route.routes.firstIndex(where: { $0.name == routeName }) else {
            print("Ruta no encontrada.")
            return
        }
        
        print("Introduce el nombre del punto que quieres añadir:")
        guard let pointNameToAdd = readLine(), let pointToAdd = points.first(where: { $0.name == pointNameToAdd }) else {
            print("Punto no encontrado.")
            return
        }
        
        print("¿Dónde quieres añadir el punto? (1 para inicio, 2 para final):")
        guard let positionChoice = readLine(), let position = Int(positionChoice), position == 1 || position == 2 else {
            print("Posición no válida.")
            return
        }
        
        let route = Route.routes[routeIndex]
        var newPoints = route.points
        
        if position == 1 {
            newPoints.insert(pointToAdd, at: 0)
        } else {
            newPoints.append(pointToAdd)
        }
        
        // Crear una nueva ruta con los puntos actualizados
        let updatedRoute = Route(name: route.name, points: newPoints)
        
        // Actualizar la ruta en Route.routes
        Route.routes[routeIndex] = updatedRoute
        print("Punto \(pointNameToAdd) añadido a la ruta \(routeName).")
    }
}
