import Foundation

class UserController {
    let user: User
    private var graph = Graph()

    init(user: User) {
        self.user = user
        setupGraph()
    }
    
    func start() {
        while true {
            print("Menú usuario - Selecciona una opción:")
            print("1. Ver todas las rutas")
            print("2. Obtener la ruta más corta entre dos puntos")
            print("3. Log out")
            
            if let choice = readLine(), let option = Int(choice) {
                switch option {
                case 1:
                    displayRoutes()
                case 2:
                    findShortestRoute()
                case 3:
                    print("Cerrando sesión.")
                    return
                default:
                    print("Opción no válida.")
                }
            }
        }
    }
    
    private func setupGraph() {
        points.forEach { graph.addVertex($0.name) }
        
        for (source, destinations) in connections {
            if graph.getNode(source) != nil {
                for destination in destinations {
                    if graph.getNode(destination) != nil {
                        let distance = Route.distanceBetween(
                            points.first(where: { $0.name == source })!,
                            points.first(where: { $0.name == destination })!
                        )
                        graph.addEdge(from: source, to: destination, weight: distance)
                    }
                }
            }
        }
    }
    
    private func displayRoutes() {
        for route in Route.routes {
            print("\(route.name) con los siguientes puntos:")
            route.points.forEach { print($0.name) }
        }
    }
    
    private func findShortestRoute() {
        let startPoint = selectPoint("Introduce el punto de inicio:")
        guard let startPoint = startPoint else {
            print("Punto de inicio no válido.")
            return
        }
        
        let endPoint = selectPoint("Introduce el punto de destino:")
        guard let endPoint = endPoint, endPoint.name != startPoint.name else {
            print("El punto de destino debe ser diferente al punto de inicio.")
            return
        }
        
        if let shortestRoute = dijkstra(source: startPoint.name, destination: endPoint.name) {
            let distance = shortestRoute.distance
            print("La distancia más corta entre \(startPoint.name) y \(endPoint.name) es: \(String(format: "%.2f", distance)) km.")
            print("La ruta es:")
            shortestRoute.path.forEach { print($0) }
        } else {
            print("No se pudo encontrar una ruta entre estos puntos.")
        }
    }
    
    private func selectPoint(_ message: String) -> Point? {
        print(message)
        guard let pointName = readLine() else { return nil }
        return points.first(where: { $0.name == pointName })
    }
    
    private func dijkstra(source: String, destination: String) -> (path: [String], distance: Double)? {
        guard let start = graph.getNode(source), let end = graph.getNode(destination) else {
            return nil
        }
        
        var distances = [String: Double]()
        var previous = [String: String]()
        var queue = PriorityQueue<GraphNode>()
        
        for node in graph.allNodes() {
            distances[node.name] = Double.infinity
            if node.name == source {
                distances[node.name] = 0
                queue.enqueue(node, priority: 0)
            } else {
                queue.enqueue(node, priority: Double.infinity)
            }
        }
        
        while let current = queue.dequeue() {
            if current.name == destination {
                break
            }
            
            for (neighbor, weight) in current.neighbors {
                let alt = distances[current.name]! + weight
                if alt < distances[neighbor.name]! {
                    distances[neighbor.name] = alt
                    previous[neighbor.name] = current.name
                    if let index = queue.index(of: neighbor) {
                        queue.updatePriority(index, priority: alt)
                    }
                }
            }
        }
        
        if let distance = distances[destination], distance != Double.infinity {
            var path = [String]()
            var current = destination
            while let prev = previous[current] {
                path.append(current)
                current = prev
            }
            path.append(source)
            return (path: path.reversed(), distance: distance)
        }
        
        return nil
    }
}
