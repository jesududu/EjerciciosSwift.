import Foundation

class LoginController {
    private var userService = UserService()
    
    func start() {
        while true {
            print("Bienvenido a SnowTrails")
            print("1. Acceder como usuario")
            print("2. Acceder como administrador")
            print("3. Salir")
            
            if let choice = readLine(), let option = Int(choice) {
                switch option {
                case 1:
                    login(role: "user", onSuccess: { user in
                        print("Accediendo como usuario: \(user.name)")
                        UserController(user: user).start()
                    }, onFailure: { error in
                        print("Error al iniciar sesión: \(error.localizedDescription)")
                    })
                case 2:
                    login(role: "admin", onSuccess: { user in
                        print("Accediendo como administrador: \(user.name)")
                        AdminController(user: user).start()
                    }, onFailure: { error in
                        print("Error al iniciar sesión: \(error.localizedDescription)")
                    })
                case 3:
                    print("Saliendo de la aplicación.")
                    exit(0)
                default:
                    print("Opción no válida.")
                }
            }
        }
    }
    
    private func login(role: String, onSuccess: @escaping (User) -> Void, onFailure: @escaping (Error) -> Void) {
        print("Introduce tu email:")
        guard let email = readLine(), validateEmail(email) else {
            onFailure(NSError(domain: "Login Error", code: 1, userInfo: [NSLocalizedDescriptionKey: "Email inválido."]))
            return
        }
        print("Introduce tu contraseña:")
        guard let password = readLine() else {
            onFailure(NSError(domain: "Login Error", code: 2, userInfo: [NSLocalizedDescriptionKey: "Contraseña no válida."]))
            return
        }
        
        if let user = userService.getUser(email: email, password: password) {
            do {
                let userRole = try user.getRole()
                if userRole == role {
                    onSuccess(user)
                } else {
                    onFailure(NSError(domain: "Login Error", code: 3, userInfo: [NSLocalizedDescriptionKey: "El rol del usuario no coincide."]))
                }
            } catch {
                onFailure(error)
            }
        } else {
            onFailure(NSError(domain: "Login Error", code: 4, userInfo: [NSLocalizedDescriptionKey: "Email o contraseña incorrectos."]))
        }
    }
    
    private func validateEmail(_ email: String) -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.(es|com)"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: email)
    }
}
