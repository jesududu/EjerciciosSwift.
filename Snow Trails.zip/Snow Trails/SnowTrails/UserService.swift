import Foundation

// MARK: - UserService

/// Estructura que gestiona las operaciones relacionadas con los usuarios en la aplicación.
public struct UserService {
    /// Array privado que almacena los usuarios. Inicialmente contiene usuarios predefinidos.
     var users: [User] = User.initialUsers

    /// Busca y retorna un usuario basado en su email y contraseña.
    /// - Parameters:
    ///   - email: El email del usuario a buscar.
    ///   - password: La contraseña del usuario.
    /// - Returns: El usuario si se encuentra, `nil` en caso contrario.
     mutating func getUser(email: String, password: String) -> User? {
        return users.first(where: { $0.email == email && $0.password == password })
    }
    
    /// Añade un nuevo usuario al sistema si el email no está ya en uso.
    /// - Parameters:
    ///   - name: El nombre del usuario nuevo.
    ///   - email: El email del usuario nuevo.
    ///   - password: La contraseña del usuario nuevo.
    /// - Returns: `true` si el usuario fue añadido con éxito, `false` si el email ya existe.
   public mutating func addUser(name: String, email: String, password: String) -> Bool {
        guard !users.contains(where: { $0.email == email }) else { return false }
        users.append(User(name: name, email: email, password: password, role: "user"))
        return true
    }
    
    /// Elimina a los usuarios con el nombre especificado, pero solo si son usuarios normales.
    /// - Parameter name: Nombre del usuario a eliminar.
    /// - Returns: El número de usuarios eliminados.
    mutating func deleteUser(name: String) -> Int {
        let initialCount = users.count
        users.removeAll { $0.name == name && $0.role == "user" }
        return initialCount - users.count
    }
    
    /// Retorna una lista de todos los usuarios en el sistema.
    /// - Returns: Array de todos los usuarios.
    func listUsers() -> [User] {
        return users
    }
}
